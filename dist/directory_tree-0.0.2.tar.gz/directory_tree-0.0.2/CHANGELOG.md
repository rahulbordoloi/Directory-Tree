Change Log
==========

0.0.1 (06/10/2020)
-------------------
-  First Release (Initial)
*  Prettified Tree Structure

0.0.2 (15/10/2020)
-------------------
-  Second Release
*  Added String Representation for GUI Log.